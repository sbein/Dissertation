#!/bin/bash

pdflatex -interaction=nonstopmode -synctex=1 aux_material.tex > aux_material.log 2>&1
